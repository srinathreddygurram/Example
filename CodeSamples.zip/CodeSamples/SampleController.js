
var bizuserCompareController = function ($scope, $state, $stateParams, $sce, $compile, bizuserCompareService, bizuserWebAnalyticsService, bizuserDashboardService, bizuserMessageService, accessLocalStorage, BizUserMessage, bizuserCmnHlprService, $rootScope, cmnHlpr) {
    //Biz. User Mashup Controller

	if (navigator.userAgent.indexOf('MSIE 10.0') != -1 || navigator.userAgent.indexOf('Trident/')>0) {
	    $state.go('bizUser.CompareTab.tworeports');
	}		
	
	
	$("#bizUserDashboardTab").removeClass("activeTab");
		$("#bizUserVisualizationTab").removeClass("activeTab");
		$("#bizUserCompareTab").addClass("activeTab");
	

	var shareddate = new Date();
	var isFullScreen= 0;
	var reportsArray = [0, 0, 0, 0, 0, 0];
	var patternstyle;
	if (patternstyle == undefined) {
		
	    patternstyle = 2;
	}
	$scope.name = accessLocalStorage.getData('selectedReportByBizUserForCompare' + $scope.currentUserId);
	$scope.loadtemplate = true;
	$scope.selectedDashboard = {};
	
	
	
	$scope.initCompareController = function (name) {
		$scope.savebutton = true;
		$scope.sharebutton = true;
		$scope.commentbutton = true;
	   $scope.getUserList();
	   
		if ($stateParams.selecteddashboard) {
		
			$scope.showSharedDashboard($stateParams.selecteddashboard);
		}
		
		$scope.saveSelectedReportIdForCompare1(name, 1);
		
		$scope.getSavedDashboards();
		$scope.shareddashboardsToUsers();

		$('.addField').addClass('used');
		

		$scope.saveDashboardid = "";
		$scope.comment = {};

		

		$scope.name = accessLocalStorage.getData('selectedReportByBizUserForCompare' + $scope.currentUserId);
		$scope.reportURL1 = '';
		$scope.reportURL2 = '';
		$scope.reportURL3 = '';
		$scope.reportURL4 = '';
		$scope.reportURL5 = '';
		$scope.reportURL6 = '';

		$scope.currentUserId = accessLocalStorage.getData('currentUserId');
		$scope.currentUserName = accessLocalStorage.getData('currentUserName');

		$scope.showBackButton = false;
		
		$scope.selectedDashboard = {};
		
		$scope.selectedDashboard.dashboardname=BizUserMessage.newmashup;
		
		if($stateParams.selecteddashboard){
			$scope.selectedDashboard.dashboardname = $stateParams.selecteddashboard.dashboardname;
		}
		
		
	

		$scope.enableReportSelection = true;
		$scope.groupnamevalue = false;
		if ($scope.name) {
		    $scope.showBackButton = true;
		}
		else {
		    $scope.showBackButton = false;
		}

		for (var reportNum = 1; reportNum <= 6; reportNum++) {
		    accessLocalStorage.setData('userBehaviourId' + reportNum, '');
		}


	}
	

	$scope.getUserList = function () {
	    var userList = bizuserMessageService.getUserList();
	    userList.then(
            function (data) {
                if (data.length >= 0) {
                    $scope.usersForMultiSelect = angular.copy(data);
                }
                else {
                    //alert(BizUserMessage.noUsers);
					 $scope.infbisolnpopup = {
						content: BizUserMessage.noUsers,
						popUpType: 'infbisoln-popup-info'
					};
					$scope.popUpStatus = true;
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: error,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });
	}
	
	//For Iframe Fix
	
	$scope.saveSelectedReportIdForCompare1 = function (report, divID) {
		
		
		var urlString = report.url;
		var initial = urlString.substring(0,4);
		
		if(initial != 'http'){
			
			urlString = urlString.replace("\\\\", "//");
			
			urlString = urlString.replace(/\\/g,"/");
		
			$scope.fetchFileObjectToClient1(urlString, report, divID);
		}
		else{
			$scope.getReportForReportId(report, divID);
		}
	}
	
	
	$scope.fetchFileObjectToClient1 = function (reportURL, report, divID) {
		var fileObjects = bizuserDashboardService.fetchFileObjectToClient(reportURL);
        fileObjects.then(
            function (data) {
                if (data.length > 0) {
					accessLocalStorage.setData('fileObjectVariableByBizUser' + $scope.currentUserId + report.idReports, data);
					$scope.getReportForReportId(report, divID);
                }
                else {
                    $scope.infbisolnpopup = {
                        content: "File Object could not be fetched in the app: " + data,
                        popUpType: 'infbisoln-popup-error'
                    };
                    $scope.popUpStatus = true;
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: error,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });
	}

	$scope.goBackToDashboard = function () {

		var reports = bizuserDashboardService.getReportsListNMetaDataForUser($scope.currentUserId);
        reports.then(
            function (data) {
                if (data[0].length >= 0) {
                    //changed above
	
					for(var i = 0; i < data[0].length; i++) {
                        accessLocalStorage.setData('fileObjectVariableByBizUser' + $scope.currentUserId + data[0][i].idReports, "");
                    }
		
                    
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: error.message,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });
	
		$state.go("bizUser.Dashboard");
	}
		
    $scope.getCommentsForMashup = function () {
		if($scope.saveDashboardid){
		 $scope.selectedDashboard.idsavedashboard = $scope.saveDashboardid; 	
		}
        var comments = bizuserCompareService.getCommentsForMashup($scope.selectedDashboard.idsavedashboard);
        comments.then(
            function (data) {
                if (data.length >= 0) {
                    $scope.comments = data;
                }
                else {
                    $scope.infbisolnpopup = {
                        content: data,
                        popUpType: 'infbisoln-popup-info'
                    };
                    $scope.popUpStatus = true;
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: error,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });
    }
    
    $scope.addCommentForMashup = function () {
		
		if($scope.saveDashboardid){
		 $scope.selectedDashboard.idsavedashboard = $scope.saveDashboardid; 	
		}
        var addComment = bizuserCompareService.addCommentForMashup($scope.selectedDashboard.idsavedashboard, $scope.currentUserId, $scope.comment.commentText);
        addComment.then(
            function (data) {
                if (data > 0) {
                    $scope.getCommentsForMashup();
                    //Reset Comment Field
                    $scope.comment.commentText = '';
                    if (angular.isUndefined($scope.addCommentForm) == false) {
                        $scope.addCommentForm.$setPristine();
                        $scope.addCommentForm.$setUntouched();
                    }
                }
                else {
                    $scope.infbisolnpopup = {
                        content: data,
                        popUpType: 'infbisoln-popup-error'
                    };
                    $scope.popUpStatus = true;
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: error,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });
    }
    
    $scope.deleteCommentForMashup = function (commentId) {
        document.querySelector('#dashboardCommentsModal').close();
        $scope.custominfbisolnpop = {
            content: BizUserMessage.deleteComment,
            popUpType: 'custominfbisoln-popup-success'
        };
        $scope.custompopUpStatus = true;
        $scope.confirm = function () {
            var comments = bizuserCompareService.removeCommentFromMashup(commentId, $scope.saveDashboardid, $scope.currentUserId);
            comments.then(
                function (data) {
                    if (data.length > 0) {
                        $scope.getCommentsForMashup();
                        $scope.custompopUpStatus = false;
                    }
                    else {
                        $scope.infbisolnpopup = {
                            content: BizUserMessage.noComments,
                            popUpType: 'infbisoln-popup-info'
                        };
                        $scope.popUpStatus = true;
                        $scope.custompopUpStatus = false;
                    }
                },
                function (error) {
                    $scope.infbisolnpopup = {
                        content: error,
                        popUpType: 'infbisoln-popup-error'
                    };
                    $scope.popUpStatus = true;
                    $scope.custompopUpStatus = false;
                });
            $scope.custompopUpStatus = false;

        }
        $scope.cancel = function () {
            $scope.custompopUpStatus = false;
        }
    }    
    
    $scope.closeModal = function (modalId) {
        document.querySelector('#' + modalId).close();
    }

    var initalReportHeight = 0;
    
    $scope.resizeIframe = function (divId) {
        if (isFullScreen == 0) {
            $rootScope.initalReportHeight = document.getElementById(divId).clientHeight - 50;
            isFullScreen = 1;
        }
        else
            isFullScreen = 0;
        bizuserCmnHlprService.resizeIframe(divId, isFullScreen, $rootScope.initalReportHeight + 'px');
    }

    
    $scope.getReportForReportId = function (report, divID) {
        
    $(".is-visible").removeClass("is-visible");    
        if (report.idReports) {
            var reports = bizuserCompareService.getReportDetailsForViewReport(report.idReports, $scope.currentUserId);
            reports.then(
                function (data) {
                    if (data.length > 0) {
						
						
						//$scope.saveSelectedReportIdForCompare1(report);
						
						
                        $scope.compareWebAnalytics(divID, report.idReports);
                        $scope.displayReportData(divID, data);
                        $scope['reportURL'+divID] = $sce.trustAsResourceUrl(data[0].url);
						
						var urlString = data[0].url;//ForIFrameFix
						var initial = urlString.substring(0,4);//ForIFrameFix
						
                        $scope.id = data[0].idReports;
                        reportsArray[divID-1] = $scope.id;
                        $scope['report' + divID] = data[0];
                        $("#demo-menu-lower-right"+(divID+1)).removeAttr("disabled");
                        $scope.getReportsToCompare();

                        $("#reportHeading"+divID).css("display", "block");
                        $("#reportHeading"+divID).html("");

                        $("#panelview" + divID).addClass('overflow1');

                        var numOfRows = parseInt((patternstyle.toString())[0]);
						
                        if ((patternstyle.toString())[1])
                            var numOfCols = parseInt((patternstyle.toString())[1]);
                        else
                            var numOfCols=1;

                        if (divID == numOfRows * numOfCols){
                            $scope.savebutton = false;
						}
						
						
						//For IFrame Fix
						
						//$scope.textToLoadInIFrame = accessLocalStorage.getData('fileObjectVariableByBizUser' + $scope.currentUserId + report.idReports);
						$scope['textToLoadInIFrame'+divID] = accessLocalStorage.getData('fileObjectVariableByBizUser' + $scope.currentUserId + report.idReports);
						
						//accessLocalStorage.setData('fileObjectVariableByBizUser' + $scope.currentUserId, "");
						
						// var sourceText1 = "";
						$scope['sourceText1'+divID] = "";
						
						if(initial == 'http'){
							$scope['sourceText1'+divID] = $scope['reportURL'+divID];
						}
						else{
							$scope['sourceText1'+divID] = "data:application/pdf;base64," + $scope['textToLoadInIFrame'+divID];
						}
						
						$("#admin_pdfExpanded" +divID).empty();
						
						$("#admin_pdfExpanded"+divID).append("<object class='reportiFrameObject' id='report" + divID + "URL' data='" + $scope['sourceText1'+divID] + "' style='height: 465px; width: 100%;'>" +
											"<embed src='" + $scope['sourceText1'+divID] + "' style='height: 465px ; width: 100%'> " +
										"</object>");
						
						
						$compile($("#admin_pdfExpanded"+divID))($scope);
						
						
						
                    }
                    else {
                        $scope.infbisolnpopup = {
                            content: BizUserMessage.noReports,
                            popUpType: 'infbisoln-popup-info'
                        };
                        $scope.popUpStatus = true;
                    }
                },
            function (error) {
                    $scope.infbisolnpopup = {
                        content: BizUserMessage.noReports,
                        popUpType: 'infbisoln-popup-info'
                    };
                    $scope.popUpStatus = true;
                });
        }
		
    }
       
    
    $scope.resetForm = function () {        
        $scope.addNewGroupName = "";
        $scope.groupDesc = "";
        $scope.selectedDashboard.userDtls = "";		
    }
	
	$('.addField').blur(function () {
        var $this = $(this);
        if ($this.val()) {
            $this.addClass('used');
        }
        else {
            $this.removeClass('used');
        }
    
    });
	
	
	$('.compField').addClass('used1');
    
    $scope.addSavedashboards = function () {        
        var dashboardname = $("#newGroupName").val();
        var description = $("#groupDesc").val();

        var date = new Date();
        if (patternstyle == undefined) {
            patternstyle = 2;
        }
		document.getElementById("messageTitle").value= dashboardname;
        document.getElementById("messageContent").value= description;
		
		
		$scope.dashname = dashboardname;
		$scope.desc = description ;
		$scope.reparray = reportsArray;
		$scope.pstyle = patternstyle;
		$scope.datevar = date;       
		
		
        var savedReports = bizuserCompareService.addSavedDashboards(reportsArray, patternstyle, dashboardname, description, date);
		 savedReports.then(
            function (data) {
				if(data.length > 0){
					$scope.saveDashboardid = data[0].id;					 
				}
				else if (data.length == 0) {
				    $scope.infbisolnpopup = {
				        content: BizUserMessage.noMashups,
				        popUpType: 'infbisoln-popup-info'
				    };
				    $scope.popUpStatus = true;
				}
				else {
				    $scope.infbisolnpopup = {
				        content: BizUserMessage.getSavedReportsError,
				        popUpType: 'infbisoln-popup-info'
				    };
				    $scope.popUpStatus = true;
				}
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: BizUserMessage.getSavedReportsError,
                    popUpType: 'infbisoln-popup-info'
                };
                $scope.popUpStatus = true;
            });
			
        
        if (document.getElementById("newmashupPtext") != null) {
            document.getElementById("newmashupPtext").innerHTML = dashboardname;
			$scope.selectedDashboard.dashboardname = dashboardname;
        }
        
        if (document.getElementById("newmashupPtext").innerHTML != "New MashUp") {
            
            bizuserCompareService.updateDashboard(reportsArray, dashboardname, description);
            $scope.groupnamevalue = true;
						
        }
        
        
        $scope.getSavedDashboards();
        
        document.querySelector('#addDashboardForm').close();
        
        $scope.popUpStatus = true;
        $scope.infbisolnpopup = {
            content: BizUserMessage.mewMashUp,
            popUpType: 'infbisoln-popup-info'

        };
		$scope.sharebutton = false;
		$scope.commentbutton = false;
    }
    
    $scope.sharedashboardmodel = function () {
        dialogPolyfill.registerDialog(document.querySelector('#shareDashboardForm'));
        document.querySelector('#shareDashboardForm').showModal();		
		$scope.shareddashboardsToUsers();
    }

    //function to check whether all divs in the templates have reports selected
    $scope.savedashBoardmodel = function () {

        var a = isNaN(parseInt(patternstyle.toString()[1]));
        var b = isNaN(parseInt(patternstyle.toString()[1])) ? 1 : parseInt(patternstyle.toString()[1]);
        var divsCount = parseInt(patternstyle.toString()[0]) * (isNaN(parseInt(patternstyle.toString()[1])) ? 1 : parseInt(patternstyle.toString()[1]));
        var isReportsSelected=1;
        for (var cnt = 1; cnt <= divsCount; cnt++) {
            //if ($scope['reportURL' + cnt] == "") {
			if ($scope['sourceText1'+cnt] == undefined) {
                isReportsSelected = 0;
                break;
            }
        }
		
		//console.log(isReportsSelected);
		
        if (isReportsSelected != 0) {
            dialogPolyfill.registerDialog(document.querySelector('#addDashboardForm'));
            document.querySelector('#addDashboardForm').showModal();
        }
        else {
            $scope.infbisolnpopup = {
                content: BizUserMessage.addReportsToSave,
                popUpType: 'infbisoln-popup-info',
            };
            $scope.popUpStatus = true;
        }
    }

    $scope.commentsdashBoardModel = function () {
        dialogPolyfill.registerDialog(document.querySelector('#dashboardCommentsModal'));
        document.querySelector('#dashboardCommentsModal').showModal();
    }
    
    $scope.shareDashboard = function () {
	
		if($scope.desc){
		$scope.selectedDashboard.description = $scope.desc;		
		}
		 if($scope.dashname){
		$scope.selectedDashboard.dashboardname = $scope.dashname;
		}
		if( $scope.reparray){
		$scope.selectedDashboard.reportsArray = $scope.reparray;
		}
		if($scope.pstyle){		
		$scope.selectedDashboard.patternstyle = $scope.pstyle;
		}
		if( $scope.datevar){
        $scope.selectedDashboard.newdatetime = $scope.datevar;
		}
		if($scope.saveDashboardid){
		 $scope.selectedDashboard.idsavedashboard = $scope.saveDashboardid; 	
		}
		
		
		if($scope.userslist){				
		    $scope.selectedDashboard.addUserDtls = cmnHlpr.getExclusiveElements($scope.userslist, $scope.oldusernamessharedetails, 'idsavedashboard');
		    $scope.selectedDashboard.rmvUserDtls = cmnHlpr.getExclusiveElements($scope.oldusernamessharedetails, $scope.userslist, 'idsavedashboard');
        }
		
		
        var sharedashboard = bizuserCompareService.shareDashboard($scope.selectedDashboard);
        sharedashboard.then(
            function (data) {
                if (data > 0) {
                    
                    //var getSharedDashboard = bizuserCompareService.getSharedDashboard();
                    $scope.getSharedDashboard();  
                    document.querySelector('#shareDashboardForm').close();  
                    $scope.infbisolnpopup = {
                        content: BizUserMessage.dashboardSuccess,
                        popUpType: 'infbisoln-popup-success'
                    };
                    $scope.popUpStatus = true;
                    $scope.selectedDashboard.addUserDtls = [];
                }
                else {
                    
                    $scope.infbisolnpopup = {
                        content: BizUserMessage.noDashboardShared,
                        popUpType: 'infbisoln-popup-info'
                    };
                    $scope.popUpStatus = true;
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: BizUserMessage.noServer,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });	
			
		$scope.shareddashboardsToUsers();
		
		
		
    }
	
	$scope.getUsersForSharedReports = function(saveDashboardid){
				var userslistforsharedreports = bizuserCompareService.getUsersForSharedDashboards(saveDashboardid);
				userslistforsharedreports.then(
				function(data){
				if(data.length >=0){
					for(var i=0;i<data.length;i++){
						$scope.userslist = angular.copy(data);
						
						//console.log($scope.userslist);
					}
				}
				else {
                    $scope.userlist = [];
					//console.log("inside empty")
                }
			 });
			
		}
	

	$scope.shareddashboardsToUsers = function(){
		var shareddashboards = bizuserCompareService.shareddashboardsToUsers();
		shareddashboards.then(
			function(data){
				if(data.length >=0){
				    $scope.shareddashboardslist = data;
				   
				    $scope.oldusernamessharedetails = angular.copy(data);
				   // alert($scope.shareddashboardslist.length);
				    //alert($scope.share);
				    if ($scope.shareddashboardslist.length != 0 && $scope.share==0) {
				        $(".sharedmashupdiv").toggle();
				        $(".maindiv").hide();
				        $(".newmashupdiv").hide();
				    } else {
				        if ($scope.share == 0) {
				            $scope.infbisolnpopup = {
				                content: BizUserMessage.noSharedMashups,
				                popUpType: 'infbisoln-popup-info'
				            };
				            $scope.popUpStatus = true;

				        }
				       
				    }

				}
				else {
                    $scope.shareddashboardslist = [];
				}

				$scope.share = 1;
			 },
            function (error) {
                $scope.infbisolnpopup = {
                    content: BizUserMessage.noServer,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });
	}
	
	
	
	
	$scope.getSharedDashboard = function () {
     
        var getSharedDashboard = bizuserCompareService.getSharedDashboard();
        getSharedDashboard.then(
            function (data) {
                if (data.length >= 0) {
                    $scope.infbisolnpopup = {
                        content: BizUserMessage.sharedDashboards,
                        popUpType: 'infbisoln-popup-success'
                    };
                    $scope.popUpStatus = true;
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: error,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });

    }
    

    $scope.showSavedDashboard = function (saveDashboard) {
		
		$scope.selectedDashboard = saveDashboard;		
        $(".newmashupdiv").hide();
		$(".sharedmashupdiv").hide();      
		$scope.sharebutton = false;
		$scope.commentbutton = false;		
		
        var reportIds = saveDashboard.reportId;
		//var reportIds = saveDashboard;
		
        $scope.enableReportSelection = false;
        $scope.groupnamevalue = false;
        loadTemplateDivs(saveDashboard.patternstyle);
		$scope.loadtemplate = false;
        
        var accessreports = [];
        var reports = bizuserDashboardService.getReportsListNMetaDataForUser($scope.currentUserId);
        loadTemplateReports(saveDashboard, reportIds);

    }
    
       $scope.showSharedDashboard = function(saveDashboard){
		 
		$scope.selectedDashboard = saveDashboard;
		
        $(".newmashupdiv").hide();
		$(".sharedmashupdiv").hide();
		$scope.sharebutton = true;
		$scope.commentbutton = false;
		
        var reportIds = saveDashboard.reportId;
		//var reportIds = saveDashboard;
		
        loadTemplateDivs(saveDashboard.patternstyle);        
        loadTemplateReports(saveDashboard, reportIds);
		$scope.loadtemplate = false;
			
       }    
    
    $scope.getSavedDashboards = function () {
        // used to get saveed mashups
        
        var getsavedReports = bizuserCompareService.getSavedDashboards();        
        getsavedReports.then(
            function (data) {              
                if (data.length >=0) {
                    $scope.saveDashboardList = data;
                     
                  //  alert($scope.saveDashboardList.length);
                   // alert($scope.save);
                    if ($scope.saveDashboardList.length != 0 && $scope.save == 0) {
                        $(".newmashupdiv").toggle();
                        $(".maindiv").hide();
                        $(".sharedmashupdiv").hide();
                    } else {
                        if ($scope.save == 0) {
                            $scope.infbisolnpopup = {
                                content: BizUserMessage.noSavedMashups,
                                popUpType: 'infbisoln-popup-info'
                            };
                            $scope.popUpStatus = true;
                        }

                    }

                    for (var i = 0; i < data.length; i++) {
                        var reportIds = data[i].reportId;
                        var match = reportIds.split(',');
                        for (var a in match) {
                            var reportId = match[a];
                        }
                    }
                    
                }
                else {
                    $scope.saveDashboardList = [];
                }
                $scope.save = 1;
            });
			
    }
    
    $scope.removedashboard = function (saveDashboard) {        
        $scope.custominfbisolnpop = {
            content: BizUserMessage.removeDashboard,
            popUpType: 'custominfbisoln-popup-success'

        };
        $scope.custompopUpStatus = true;
        $scope.confirm = function () {
            var removeDashboards = bizuserCompareService.removeDashboards(saveDashboard.dashboardname, saveDashboard.reportId);
            removeDashboards.then(
                function (data) {                    
                    if (data.length > 0) {
                        $scope.getSavedDashboards();
                    }
                });
            $scope.custompopUpStatus = false;
            $(".newmashupdiv").hide();
        }
        $scope.cancel = function () {
            $scope.custompopUpStatus = false;
        }
    }
    
    
    
    $scope.addFavoriteReportForUser = function (reportId, divId) {
        
        var reports = bizuserDashboardService.addFavoriteReportForUser(reportId.idReports, $scope.currentUserId);
        reports.then(
            function (data) {
                if (data > 0) {
                    //$scope.getReportForReportId(reportId, divId);
					$scope.saveSelectedReportIdForCompare1(reportId, divId);
                }
                else {
                    
                    $scope.infbisolnpopup = {
                        content: BizUserMessage.noRptAsFav,
                        popUpType: 'infbisoln-popup-info'
                    };
                    $scope.popUpStatus = true;
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: BizUserMessage.noServer,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });
    }

    $scope.addLikeReportForUser = function (reportId, divId) {
        
        var reports = bizuserDashboardService.addLikeReportForUser(reportId.idReports, $scope.currentUserId);
        reports.then(
            function (data) {
                if (data > 0) {
                    //$scope.getReportForReportId(reportId, divId);
					$scope.saveSelectedReportIdForCompare1(reportId, divId);
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: BizUserMessage.noServer,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });
    }
    
    $scope.removeLikeReportForUser = function (reportId, divId) {
        var reports = bizuserDashboardService.removeLikeReportForUser(reportId.idReports, $scope.currentUserId);
        reports.then(
            function (data) {
                if (data.length > 0) {
                    //$scope.getReportForReportId(reportId, divId);
					$scope.saveSelectedReportIdForCompare1(reportId, divId);
                }
            },
                function (error) {
                $scope.infbisolnpopup = {
                    content: error,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
                $scope.custompopUpStatus = false;
            });
    }

    $scope.updateLikeReportForUser = function (isLiked, reportId, divId) {
        if (isLiked) {
            $scope.removeLikeReportForUser(reportId, divId);
        } else {
            $scope.addLikeReportForUser(reportId, divId);
        }
    }
    
    $scope.webAnalyticsEndTime = function (reportNumber) {
        var userBehavior = bizuserWebAnalyticsService.setEndTimeForReport(accessLocalStorage.getData('userBehaviourId' + reportNumber));
        userBehavior.then(
            function (data) {
                if (data.length > 0) {
                    accessLocalStorage.removeData('userBehaviourId' + reportNumber);
                }
                else {
                    $scope.infbisolnpopup = {
                        content: data,
                        popUpType: 'infbisoln-popup-info'
                    };
                    $scope.popUpStatus = true;
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: error,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });
    }
    
    $scope.webAnalyticsStartTime = function (reportNumber, name) {
        var userBehavior = bizuserWebAnalyticsService.setStartTimeForReport($scope.currentUserId, name);
        userBehavior.then(
            function (data) {
                if (data) {
                    accessLocalStorage.setData('userBehaviourId' + reportNumber, data);
                }
                else {
                    $scope.infbisolnpopup = {
                        content: data,
                        popUpType: 'infbisoln-popup-info'
                    };
                    $scope.popUpStatus = true;
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: error,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });
    }
    
    $scope.compareWebAnalytics = function (reportNumber, name) {
        if (accessLocalStorage.getData('userBehaviourId' + reportNumber) != null && accessLocalStorage.getData('userBehaviourId' + reportNumber) != '') {
            //Record End Time for Web Analytics
            $scope.webAnalyticsEndTime(reportNumber);
        }
        //Record Start Time for Web Analytics
        $scope.webAnalyticsStartTime(reportNumber, name);
    }

    $scope.displayReportData = function (frameID, data) {
        $scope["reportURL" + frameID] = $sce.trustAsResourceUrl(data[0].url);
        $scope.id = data[0].idReports;
        reportsArray[frameID - 1] = $scope.id;
        $scope['report' + frameID] = data[0];     
        
        if (frameID < 6)
            $("#demo-menu-lower-right" + (frameID + 1)).removeAttr("disabled");
        
        $scope.getReportsToCompare();
        
        $("#reportHeading" + frameID).css("display", "block");
        $("#reportHeading" + frameID).html("");
        
        // var reportURL = $("#report" + frameID + "URL").clone();
        // reportURL.find('embed').attr('src', $scope["reportURL" + frameID]);
        // $("#report" + frameID + "URL").attr('data', $scope["reportURL" + frameID]);
        // $("#report" + frameID + "URL").replaceWith(reportURL);
    }
    
    
    $scope.getReportsToCompare = function () {
		  
        var reports = bizuserCompareService.getReportsToCompare($scope.$parent.currentUserId);
        reports.then(
            function (data) {                
                if (data.length > 0) {
                    $scope.columnReports = data[0];					
                }
                else {
                    $scope.infbisolnpopup = {
                        content: BizUserMessage.noReports,
                        popUpType: 'infbisoln-popup-info'
                    };
                    $scope.popUpStatus = true;
                }
            },
            function (error) {
                $scope.infbisolnpopup = {
                    content: error,
                    popUpType: 'infbisoln-popup-error'
                };
                $scope.popUpStatus = true;
            });

    }
    
   
    $scope.newmashupFunction = function () {
        // used to create new mashup layout  
        $scope.save = 0;
        $scope.getSavedDashboards();
        
       // if ($scope.saveDashboardList.length != 0) {
       //     $(".newmashupdiv").toggle();
       //     $(".maindiv").hide();
       //      $(".sharedmashupdiv").hide();
       // } else {
       //     $scope.infbisolnpopup = {
       //         content: BizUserMessage.noSavedMashups,
       //         popUpType: 'infbisoln-popup-info'
       //     };
       //     $scope.popUpStatus = true;
       // }


        //$(".newmashupdiv").toggle();
        //$(".maindiv").hide();
		// $(".sharedmashupdiv").hide();		 
		// $scope.getSavedDashboards();
		// alert($scope.saveDashboardList.length);
    }
	
    $scope.sharedmashupFunction = function () {
         //used to retrive shared mashups     
        //$(".sharedmashupdiv").toggle();
        //$(".maindiv").hide();
		//$(".newmashupdiv").hide();		
        //$scope.shareddashboardsToUsers();
        $scope.share = 0;
        $scope.shareddashboardsToUsers();
       
        
    }
    
    $scope.toggleTemplateDropdown = function () {        
        $(".maindiv").toggle();
        $(".newmashupdiv").hide();
		 $(".sharedmashupdiv").hide();
    }

    $scope.close = function () {
      
        $(".newmashupdiv").hide();
        $(".sharedmashupdiv").hide();
        $(".maindiv").hide();
    }
 
    $(".pageHeader").click(function () {
        $(".newmashupdiv").hide();
        $(".sharedmashupdiv").hide();
        $(".maindiv").hide();

    });

    $scope.reportURL1 = $stateParams.report1URL;
    $scope.reportURL2 = $stateParams.report2URL;

    console.log('ujksdffhksjd: ' + $stateParams.report1URL);

    $scope.loadTemplate = function (pattern) {
	
        $scope.enableReportSelection = true;
        patternstyle = pattern;
        $scope.resetForm();
        $(".maindiv").hide();
		//$(".maindiv").toggle();
        $(".newmashupP").css("display", "block");
        $scope.selectedDashboard = {};
        $(".saveDashboard").css("display", "block");

        $scope.groupnamevalue = false;
        $scope.sharebutton = true;
        $scope.commentbutton = true;
		
		$scope.selectedDashboard.dashboardname=BizUserMessage.newmashup;

        setTemplateDivDimensions(patternstyle);
	   


	   
    }

    //sets dimensions of all divs in the selected template
    setTemplateDivDimensions = function (pattern) {
        var divHeight = 0;
        var divWidth = 0;

        for (var cnt = 1; cnt <= pattern; cnt++) {
            if (document.getElementById("panelview" + cnt)) {
                document.getElementById("panelview" + cnt).style.width = "";
                document.getElementById("panelview" + cnt).style.height = "";
            }
            $("#panelview" + cnt).removeClass('overflow1');
        }

        //console.log(parseInt(pattern[0]));

        var divsCount = parseInt(pattern.toString()[0]) * (parseInt(pattern.toString()[1]) == undefined ? 1 : parseInt(pattern.toString()[1]));

        //var divsCount = parseInt(pattern.charAt(0)) * (parseInt(pattern.charAt(1) == undefined ? 1 : parseInt(pattern.charAt(1))));

        if (pattern.toString()[1]) {
            divWidth = (($('#allReports')[0].clientWidth) - (25 * parseInt(pattern.toString()[1]))) / parseInt(pattern.toString()[1]);
            divHeight = (($('#allReports')[0].clientHeight) - 50) / parseInt(pattern.toString()[0]);
        }
        else {
            divWidth = (($('#allReports')[0].clientWidth) - (25 * pattern)) / pattern;
            divHeight = (($('#allReports')[0].clientHeight) - (30 * pattern));
        }

        

        for (var cnt = 1; cnt <= divsCount; cnt++) {
            if (document.getElementById("panelview" + cnt)) {

                document.getElementById("panelview" + cnt).style.width = divWidth + 'px';
                document.getElementById("panelview" + cnt).style.height = divHeight + 'px';
            }
            $("#panelview" + cnt).addClass('overflow1');
        }
    }

    //set dimensions of all divs in teh selected template and load it 
    loadTemplateDivs = function (patternstyle) {
		 if ($stateParams.selecteddashboard == 'undefined' || $scope.loadtemplate == false){
		   
			setTemplateDivDimensions(patternstyle);
		}
        

        $scope.enableReportSelection = false;
        $scope.groupnamevalue = false;

        if (patternstyle == 2) {
            $state.go('bizUser.CompareTab.tworeports');;
        }
        else if (patternstyle == 3) {
            $state.go('bizUser.CompareTab.threereports');
        }
        else if (patternstyle == 22) {
            $state.go('bizUser.CompareTab.twobytworeports');
        }
        else if (patternstyle == 23) {
            $state.go('bizUser.CompareTab.twobythreereports');
        }
        else if (patternstyle == 32) {
            $state.go('bizUser.CompareTab.threebytworeports');
        }
    }


    loadTemplateReports = function (saveDashboard, reportIds) {
        var accessreports = [];
		var accessreportIds = [];
        var reports = bizuserDashboardService.getReportsListNMetaDataForUser($scope.currentUserId);
        reports.then(
            function (data) {
                for (var i = 0; i < data[0].length; i++) {
                     accessreports.push(data[0][i]);//Originally data[0][i].idReports
					accessreportIds.push(data[0][i].idReports);
                }
                var match = [];
                match = reportIds.split(',');
                for (var a in match) {
                     var reportId = match[a];
					//var reportId = match[a].reportId;
					
                    if (reportId != 0) {
                        if (accessreportIds.indexOf(parseInt(reportId)) != -1) {
                            //$scope.getReportForReportId(reportId, parseInt(a) + 1);
							$scope.saveSelectedReportIdForCompare1(accessreports[accessreportIds.indexOf(parseInt(reportId))], parseInt(a) + 1);
                        }
                        else {
                            var reports = bizuserCompareService.getReportForReportId(reportId);
                            var noaccessreports = [];
                            reports.then(
                                function (data) {
                                    for (var i = 0; i < data.length; i++) {
                                        noaccessreports.push(" " + data[i].reportName);

                                        $scope.infbisolnpopup = {
                                            content: "You dont have access to " + noaccessreports,
                                            popUpType: 'infbisoln-popup-info'
                                        };
                                        $scope.popUpStatus = true;
                                    }
                                }
                            );
                        }
                    }
                }
            });
        $scope.getUsersForSharedReports(saveDashboard.idsavedashboard);
    }

    
	$scope.resize = function(evt, ui) {
      $scope.w = ui.size.width;
      $scope.h = ui.size.height;
	  console.log(w);
	  console.log(h);
	}

	$scope.removeOverFlowAdded =function() {
	    $('[id^=panelview]').removeClass('overflow1');
	}
	
		

	
}

