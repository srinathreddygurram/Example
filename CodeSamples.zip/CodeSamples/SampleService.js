
var bizuserCompareService = function ($http, $q, $httpParamSerializerJQLike) {
    return {
        getReportForReportId: function (name) {
            var deferred = $q.defer();
            var sdata = {
                name: name
            };
            $http({
                method: 'POST',
                url: '/bizUserViewReport/getReportForReportId',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: $httpParamSerializerJQLike(sdata)
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                  deferred.reject(response);
              })
            return deferred.promise;
        },

        getReportDetailsForViewReport: function (reportId,userId) {
            var deferred = $q.defer();
            var sdata = {
                reportId: reportId,
                userId:userId
            };
            $http({
                method: 'POST',
                url: '/bizUserViewReport/getReportDetailsForViewReport',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: $httpParamSerializerJQLike(sdata)
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },

        getReportsToCompare: function (userId) {
            var deferred = $q.defer();
            var sdata = {
                userId: userId
            };
            $http({
                method: 'POST',
                url: '/bizUserDashboard/getReportsListNMetaDataForUser',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: $httpParamSerializerJQLike(sdata)
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                  deferred.reject(response);
              })
            return deferred.promise;
        },
      
		addSavedDashboards : function(reportsArray,patternstyle,dashboardname,description,date){
			 var deferred = $q.defer();
			 var sdata = {
				 reportsArray : reportsArray,
				 patternstyle : patternstyle,
				 dashboardname : dashboardname,
				 description : description,
				 date:date
			 };
			  $http({
                method: 'POST',
                url: '/bizUserViewReport/addSavedDashboards',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: $httpParamSerializerJQLike(sdata)
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                  deferred.reject(response);
              })
            return deferred.promise;
		},
		getSavedDashboards : function(){
			 var deferred = $q.defer();
			  $http({
                method: 'POST',
                url: '/bizUserViewReport/getSavedDashboards',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                  deferred.reject(response);
              })
            return deferred.promise;
		},
		removeDashboards: function (dashboardname, reportId) {
            var deferred = $q.defer();
            var sdata = {
                dashboardname: dashboardname,
                reportId: reportId
            };
            $http({
                method: 'POST',
                url: '/bizUserViewReport/removeDashboards',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: $httpParamSerializerJQLike(sdata)
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                  deferred.reject(response);
              })
            return deferred.promise;
        },
		updateDashboard : function(reportsArray,dashboardname,description){
			var deferred = $q.defer();
            var sdata = {
                reportsArray: reportsArray,
				dashboardname : dashboardname,
				description : description
            };
            $http({
                method: 'POST',
                url: '/bizUserViewReport/updateDashboard',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: $httpParamSerializerJQLike(sdata)
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                  deferred.reject(response);
              })
            return deferred.promise;
		},
		shareDashboard : function(selectedDashboard){
			
			 var deferred = $q.defer();

            $http({
                method: 'POST',
                url: '/bizUserViewReport/shareDashboard',
                headers: { 'Content-Type': 'application/json' },
                data: selectedDashboard
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                  deferred.reject(response);
              })

            return deferred.promise;
		},
		getSharedDashboard : function(){
			 var deferred = $q.defer();
			  $http({
                method: 'POST',
                url: '/bizUserViewReport/getSharedDashboard',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                  deferred.reject(response);
              })
            return deferred.promise;
		},
		
		shareddashboardsToUsers:function(){
			 var deferred = $q.defer();
			  $http({
                method: 'POST',
                url: '/bizUserViewReport/shareddashboardsToUsers',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                  deferred.reject(response);
              })
            return deferred.promise;
		},
		getUsersForSharedDashboards:function(saveDashboardid){
			 var deferred = $q.defer();
            var sdata = {
                saveDashboardid: saveDashboardid
            };
            $http({
                method: 'POST',
                url: '/bizUserViewReport/getUsersForSharedDashboards',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: $httpParamSerializerJQLike(sdata)
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                  deferred.reject(response);
              })
            return deferred.promise;
        },
        getUnreadSharedDashboard : function () {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: '/bizUserViewReport/getUnreadSharedDashboard',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getCommentsForMashup: function (mashupId) {
            var deferred = $q.defer();
            var sdata = {
                mashupId: mashupId
            };
            $http({
                method: 'POST',
                url: '/bizUserComment/getCommentsForMashup',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: $httpParamSerializerJQLike(sdata)
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        addCommentForMashup: function (mashupId, userId, comment) {
            var deferred = $q.defer();
            var sdata = {
                mashupId: mashupId,
                userID: userId,
                comment: comment
            };
            $http({
                method: 'POST',
                url: '/bizUserComment/addCommentForMashup',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: $httpParamSerializerJQLike(sdata)
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        removeCommentFromMashup: function (commentId, mashupId, userId) {
            var deferred = $q.defer();
            var sdata = {
                idcomments: commentId,
                mashupId: mashupId,
                userID: userId
            };
            $http({
                method: 'POST',
                url: '/bizUserComment/removeCommentFromMashup',
                headers: { 'Content-Type': 'application/json' },
                data: sdata
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },

        getNotifications: function (userId,recordCount) {
            var deferred = $q.defer();
            var sdata = {
                userId: userId,
                recordCount: recordCount
            };
            $http({
                method: 'POST',
                url: '/bizUserNotification/getNotifications',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: $httpParamSerializerJQLike(sdata)
            }).success(function (response) {
                deferred.resolve(response);
            })
              .error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
    }
};