﻿
var bizUserViewReportDataAccess = require("../dbScripts/bizUserViewReportDataAccess.js");
var router = require('express').Router();
var CmnHlpr = require("../Helpers/CommonHelper.js");
var nconf = require('nconf');

router.post('/getReportForReportId', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.GetReportForReportId(req.body.name, function (data) {
                //res.send(data);
                if (!data.customMsg)
                    res.send(data[0]);
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }
            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
       res.status(500).send(nconf.get('fatalErrorMsg'));
    }
}); 

router.post('/getReportDetailsForViewReport', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.GetReportDetailsForViewReport(req.body.reportId, req.body.userId, function (data) {
                //res.send(data);
                if (!data.customMsg)
                    res.send(data[0]);
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }
            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
       res.status(500).send(nconf.get('fatalErrorMsg'));
    }
}); 


router.post('/addSavedDashboards', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.AddSavedDashBoards(req.body, req.session.userId, function (data) {
                //res.send(data);

                if (!data.customMsg) {
                    res.send(data[0]);
                }
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }
            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
       res.status(500).send(nconf.get('fatalErrorMsg'));
    }
});

router.post('/getSavedDashboards', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.GetSavedDashBoards(req.session.userId,function (data) {
                if (!data.customMsg)
                    res.send(data[0]);
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }
            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
       res.status(500).send(nconf.get('fatalErrorMsg'));
    }
});

router.post('/removeDashboards', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.RemoveDashBoards(req.body.dashboardname, req.body.reportId, function (data)  {
                 if (!data.customMsg)
                    res.send(data[0][0].success.toString());
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }
            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
       res.status(500).send(nconf.get('fatalErrorMsg'));
    }
});

router.post('/updateDashboard', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.UpdateDashboard(req.body,function (data) {
                if (!data.customMsg)
                    res.send(data[0]);
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }
            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
       res.status(500).send(nconf.get('fatalErrorMsg'));
    }
});

router.post('/shareDashboard', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.ShareDashboard(req.body, req.session.userId,function (data) {
                 if (!data.customMsg){
                    //res.send(data[0][0].success.toString());
                    res.send(data[0]);
                }
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }

            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
       res.status(500).send(nconf.get('fatalErrorMsg'));
    }
});


router.post('/shareddashboardsToUsers', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.ShareddashboardsToUsers(req.session.userId,function (data) {
               if (!data.customMsg){
                    //res.send(data[0][0].success.toString());
                    res.send(data[0]);
                }
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }

            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
       res.status(500).send(nconf.get('fatalErrorMsg'));
    }
});

router.post('/getSharedDashboard', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.GetSharedDashboard(req.session.userId,function (data) {
                if (!data.customMsg)
                    res.send(data);
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }

            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
       res.status(500).send(nconf.get('fatalErrorMsg'));
    }
});

router.post('/getUsersForSharedDashboards', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.GetUsersForSharedDashboards(req.session.userId, req.body.saveDashboardid,function (data) {
                if (!data.customMsg)
                    res.send(data[0]);
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }

            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
        res.status(500).send(nconf.get('fatalErrorMsg'));
    }
});

router.post('/getUnreadSharedDashboard', function (req, res) {
    try {
        if (!req.session.userRole) {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('sessionExpiryErrorMsg'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('sessionExpiryErrorMsg'));
        }
        else if (req.session.userRole != 'Admin') {
            bizUserViewReportDataAccess.getUnreadSharedDashboard(req.session.userId, function (data) {
                if (!data.customMsg)
                    res.send(data[0]);
                else {
                    //CmnHlpr.LogInfo(req.session.userName, data);
                    CmnHlpr.LogInfo(req.session.userName, data.customMsg, data.errorType);
                    res.status(500).send({ message: data.customMsg });
                }

            });
        }
        else {
            CmnHlpr.LogInfo(req.session.userName, nconf.get('loginUserErrorMsgForBizUser'), nconf.get('authErrorType'));
            res.status(500).send(nconf.get('loginUserErrorMsgForBizUser'));
        }
    }
    catch (err) {
        CmnHlpr.LogInfo(req.session.userName, nconf.get('fatalErrorMsg') + ': ' + err.message, nconf.get('fatalErrorType'));
        res.status(500).send(nconf.get('fatalErrorMsg'));
    }
}); 


module.exports = router;